from flet import *
from questions import questions
from menu import menubar


counter=0

def main(quizpage:Page):
    quizpage.title="4T"
    quizpage.window.width=400
    quizpage.window.left=860
    quizpage.scroll='auto'

    global counter
    
    def btn_visible():
        rep1.visible=True
        rep2.visible=True
        rep3.visible=True
        rep4.visible=True

    def btn_non_visible():
        rep1.visible=False
        rep2.visible=False
        rep3.visible=False
        rep4.visible=False

    def rep_correct(e):
        print("correct")
        correction.value="correct"
        reponse_container.bgcolor=colors.GREEN
        #correction.bgcolor=colors.GREEN
        quizpage.update()
        reponse_container.bgcolor=""
            
    def rep_fausse(e):
        print("false")
        correction.value="Fausse"
        reponse_container.bgcolor=colors.RED
        #correction.bgcolor=colors.RED
        quizpage.update()
        reponse_container.bgcolor=""

    def next_question(e):
        global counter
        next_btn.text="Next"

        counter+=1
        if counter==1:
            question.value=f"{counter} ){questions["q1"]}"
            rep1.text="La science de la gestion des ressources humaine"
            rep2.text="L'ensemble des techniques utilisées pour enregistrer, classer et résumer les transactions financières d'une entreprise"
            rep3.text="L'étude des comportements des consommateurs"
            btn_visible()
            rep4.visible=False
            rep1.on_click=rep_fausse
            rep2.on_click=rep_correct
            rep3.on_click=rep_fausse
            correction.value=""
            quizpage.update()
            
        elif counter==2:
            question.value=f"{counter} ) {questions["q2"]}"
            rep1.text="7111"
            rep2.text="3421"
            rep3.visible=False
            rep1.on_click=rep_fausse
            rep2.on_click=rep_correct
            correction.value=""
            quizpage.update()

        elif counter==3:
            question.value=f"{counter} ) {questions["q3"]}"
            rep1.text="5115"
            rep2.text="5141"
            rep3.text="5161"
            rep1.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep3.on_click=rep_correct
            rep3.visible=True
            correction.value=""
            quizpage.update()
        
        elif counter==4:
            question.value=f"{counter} ) {questions["q4"]}"
            rep1.text="5115"
            rep2.text="5141"
            rep3.text="5161"
            rep1.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_correct
            rep3.visible=True
            correction.value=""
            quizpage.update()
        
        elif counter==5:
            question.value=f"{counter} ) {questions["q5"]}"
            rep1.text="Oui"
            rep2.text="Non"
            rep1.on_click=rep_correct
            rep2.on_click=rep_fausse
            rep3.visible=False
            correction.value=""
            quizpage.update()

        elif counter==6:
            question.value=f"{counter} ) {questions["q6"]}"
            rep1.text="Les dettes de l'entreprise"
            rep2.text="Les revenus de l'entreprise"
            rep3.text="Ce que l'entreprise possède"
            btn_visible()
            rep4.visible=False
            rep1.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep3.on_click=rep_correct
            correction.value=""
            quizpage.update()
            
        
        elif counter==7:
            question.value=f"{counter} ){questions["q7"]}"
            rep1.text="Ce que l'entreprise doit"
            rep2.text="Ce que l'entreprise possède"
            rep3.text="les creaces des client"
            btn_visible()
            rep4.visible=False
            rep2.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep1.on_click=rep_correct
            correction.value=""
            quizpage.update()
        
        elif counter==8:
            question.value=f"{counter} ){questions["q8"]}"
            rep1.text="Diminution d’une créance /  Augmentation d’une dette"
            rep2.text="Augmentation d’une créance / Diminution d’une dette"
            btn_visible()
            rep3.visible=False
            rep4.visible=False
            rep1.on_click=rep_correct
            rep2.on_click=rep_fausse
            correction.value=""
            quizpage.update()
        
        
        elif counter==9:
            question.value=f"{counter} ){questions["q9"]}"
            rep1.text="Capacité d'autofinancement"
            rep2.text="Capacité à investir seul sans recourir aux emprunts"
            btn_visible()
            rep3.visible=False
            rep4.visible=False
            rep1.on_click=rep_correct
            rep2.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==10:
            question.value=f"{counter} ){questions["q10"]}"
            rep1.text="Compte 7512 s'il s'agit d'une immobilisation incorporelle"
            rep2.text="Compte 7513 s'il s'agit d'une immobilisation corporelle"
            rep3.text="Tous les comptes mentionnés ci-dessus peuvent être crédités selon le type d'immobilisation"
            btn_visible()
            rep4.visible=False
            rep1.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep3.on_click=rep_correct
            correction.value=""
            quizpage.update()
        
        
        elif counter==11:
            question.value=f"{counter} ){questions["q11"]}"
            rep1.text="Document bancaire"
            rep2.text="document personnel"
            rep3.text="document qu'on achete"
            btn_visible()
            rep4.visible=False
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_correct
            correction.value=""
            quizpage.update()
        
         
        elif counter==12:
            question.value=f"{counter} ){questions["q12"]}"
            rep1.text="un depot a vue remunere"
            rep3.text="un depot a vue non remunere"
            rep2.text="un depot a terme non remunere"
            rep4.text="un depot a terme remunere"
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_correct
            correction.value=""
            quizpage.update()
        
        
        elif counter==13:
            question.value=f"{counter} ){questions["q13"]}"
            rep1.text="A. est le taux du marché monétaire"
            rep3.text="B. est un coût de financement"
            rep2.text="C. est un coût d'opportunité"
            rep4.text="D. est un indicateur avancé de la valeur des titres"
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==14:
            question.value=f"{counter} ){questions["q14"]}"
            rep1.text="A .Permet de comprendre le rôle de réserve de valeur de la monnaie."
            rep3.text="B. Dérive de la seule fonction de paiement."
            rep2.text="C. Se réfère à la valeur nominale."
            rep4.text="D. Est une notion keynésienne."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()
        
        elif counter==15:
            question.value=f"{counter} ){questions["q15"]}"
            rep1.text="A. les banques commerciales"
            rep3.text="B. les banques islamiques"
            rep2.text="C. Bank Al Maghrib"
            rep4.text="D. Le trésor public"
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()
        
        elif counter==16:
            question.value=f"{counter} ){questions["q16"]}"
            rep1.text="A. le livre journal"
            rep3.text="B. le grand livre"
            rep2.text="C. la balance"
            rep4.text="D. le livre d'inventaire "
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()
        
        
        elif counter==17:
            question.value=f"{counter} ){questions["q17"]}"
            rep1.text="A) Les aider à réaliser des opérations d'investissement."
            rep3.text="B) Les aider à renouveler les outils de production."
            rep2.text="C) Les aider à faire face à un résultat déficitaire important."
            rep4.text="D) Compenser l’écart entre le coût de revient et le prix de vente. "
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()
        
        elif counter==18:
            question.value=f"{counter} ){questions["q18"]}"
            rep1.text="A) Immobilisations en non-valeur."
            rep3.text="B) Immobilisations incorporelles"
            rep2.text="C) Immobilisations corporelles."
            rep4.text="D) Immobilisations financières"
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==19:
            question.value=f"{counter} ){questions["q19"]}"
            rep1.text="A) Négocier des délais de paiement plus courts auprès des clients."
            rep3.text="B) Négocier des délais de paiement plus courts auprès des fournisseurs."
            rep2.text="C) Diminuer la rotation des stocks de marchandises."
            rep4.text="D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()
        
        elif counter==20:
            question.value=f"{counter} ){questions["q20"]}"
            rep1.text="A) Charges à répartir sur plusieurs exercices."
            rep3.text="B) Charges constatées d’avance."
            rep2.text="C) Produits constatés d’avance."
            rep4.text="D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==21:
            question.value=f"{counter} ){questions["q21"]}"
            rep1.text="A) La division horizontale du travail."
            rep3.text="B) La division verticale du travail."
            rep2.text="C) La spécialisation des salariés"
            rep4.text="D) La rémunération au rendement"
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==22:
            question.value=f"{counter} ){questions["q22"]}"
            rep1.text="A) Les emplois stables."
            rep3.text="B) Le besoin en fonds de roulement."
            rep2.text="C) Les ressources stables."
            rep4.text="D) La trésorerie nette."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==23:
            question.value=f"{counter} ){questions["q23"]}"
            rep1.text="A) Le cas d’une immobilisation incorporelle totalement amortie."
            rep3.text="B) Le cas d’une immobilisation en non-valeur totalement amortie."
            rep2.text="C) Le cas d’une immobilisation corporelle totalement amortie."
            rep4.text="D) Le cas d’une immobilisation cédée."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==24:
            question.value=f"{counter} ){questions["q24"]}"
            rep1.text="A) La cession d’immobilisation."
            rep3.text="B) L’augmentation du capital en numéraire."
            rep2.text="C) L’acquisition d’une immobilisation."
            rep4.text="D) Le remboursement d’un emprunt à long terme."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==25:
            question.value=f"{counter} ){questions["q25"]}"
            rep1.text="A) Des bénéfices sont reportés dans l’attente d’une décision définitive de distribution ou de mise en réserve."
            rep3.text="B) Des bénéfices sont distribués sous forme de dividende."
            rep2.text="C) Des pertes des exercices antérieurs sont reportées dans l’attente de bénéfices pour les compenser."
            rep4.text="D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==26:
            question.value=f"{counter} ){questions["q26"]}"
            rep1.text="A) Les dotations aux amortissements impactent la trésorerie."
            rep3.text="B) L'achat au comptant d'un bien immobilisé modifie le patrimoine de l'entreprise."
            rep2.text="C) La cession au comptant d'un actif à sa valeur nette comptable impacte la trésorerie."
            rep4.text="D) L'impôt sur le bénéfice impacte la trésorerie."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==27:
            question.value=f"{counter} ){questions["q27"]}"
            rep1.text="A) Les coûts d'achat ont augmenté et les charges de personnel ont diminué."
            rep3.text="B) Les coûts d'achat et les charges de personnel ont diminué."
            rep2.text="C) Les coûts d'achat ont diminué et les charges de personnel ont augmenté."
            rep4.text="D) Les coûts d'achat ont augmenté et les charges de personnel sont inchangées"
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==28:
            question.value=f"{counter} ){questions["q28"]}"
            rep1.text="A) La classe 1 : Financement permanent."
            rep3.text="B) La classe 2 : Actif immobilisé."
            rep2.text="C) La classe 3 : Actif circulant."
            rep4.text="La classe 4 : Passif circulant."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==29:
            question.value=f"{counter} ){questions["q29"]}"
            rep1.text="A) À l'unanimité des associés."
            rep3.text="B) Par un ou plusieurs associés détenant les 1/3 des parts sociales."
            rep2.text="C) Par un ou plusieurs associés détenant les 2/3 des parts sociales."
            rep4.text="D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==30:
            question.value=f"{counter} ){questions["q30"]}"
            rep1.text="A) Une composante conjoncturelle qui varie avec le niveau d'activité représenté par le chiffre d'affaires"
            rep3.text="B) Les dettes qui ont financé l'investissement."
            rep2.text="C) Une composante structurelle qui dépend de la durée de stockage, des délais de paiements clients et fournisseurs."
            rep4.text="D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()

        elif counter==31:
            question.value=f"{counter} ){questions["q31"]}"
            rep1.text="A) De l'image fidèle."
            rep3.text="B) De prudence."
            rep2.text="C) D'importance significative."
            rep4.text="D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep4.on_click=rep_fausse
            rep3.on_click=rep_fausse
            rep2.on_click=rep_fausse
            rep1.on_click=rep_fausse
            correction.value=""
            quizpage.update()
                
        elif counter == 32:
            question.value = f"{counter} ) {questions['q32']}"
            rep1.text = "A) Passer les écritures comptables de régularisation."
            rep2.text = "B) Calculer les amortissements et les provisions."
            rep3.text = "C) Contrôler l'évolution du patrimoine de l'entreprise."
            rep4.text = "D) Solder l'ensemble des comptes de l'entreprise."
            btn_visible()
            rep4.on_click = rep_fausse
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 33:
            question.value = f"{counter} ) {questions['q33']}"
            rep1.text = "A) Apport en nature."
            rep2.text = "B) Apport en numéraire."
            rep3.text = "C) Apport en industrie."
            rep4.text = "D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 34:
            question.value = f"{counter} ) {questions['q34']}"
            rep1.text = "A) Une augmentation des charges d'exploitation."
            rep2.text = "B) Une diminution des charges d'exploitation."
            rep3.text = "C) Une diminution du résultat d'exploitation."
            rep4.text = "D) Une augmentation du résultat d'exploitation."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 35:
            question.value = f"{counter} ) {questions['q35']}"
            rep1.text = "A) Un excès de ressources qui restent à la disposition de l'entreprise une fois que le BFR a été financé."
            rep2.text = "B) Un excès de ressources qui restent à la disposition de l'entreprise une fois que ses investissements ont été financés."
            rep3.text = "C) Un excès de ressources qui restent à la disposition de l'entreprise une fois que ses emplois ont été financés."
            rep4.text = "D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 36:
            question.value = f"{counter} ) {questions['q36']}"
            rep1.text = "A) Les provisions ont un caractère irréversible."
            rep2.text = "B) L'amortissement est une charge déductible."
            rep3.text = "C) L'amortissement permet de revoir la valeur temporaire d'un bien."
            rep4.text = "D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 37:
            question.value = f"{counter} ) {questions['q37']}"
            rep1.text = "A) La division du travail."
            rep2.text = "B) La structure hiérarchique."
            rep3.text = "C) La communication verticale."
            rep4.text = "D) L'information écrite."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 38:
            question.value = f"{counter} ) {questions['q38']}"
            rep1.text = "A) La performance financière de l'entreprise."
            rep2.text = "B) Le degré d'intégration des activités de l'entreprise."
            rep3.text = "C) La performance commerciale de l'entreprise."
            rep4.text = "D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 39:
            question.value = f"{counter} ) {questions['q39']}"
            rep1.text = "A) Exclusivement en compte de charges."
            rep2.text = "B) Exclusivement en compte de produits."
            rep3.text = "C) Au bilan et au compte de résultat."
            rep4.text = "D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 40:
            question.value = f"{counter} ) {questions['q40']}"
            rep1.text = "A) Diminue le montant de la valeur ajoutée."
            rep2.text = "B) Augmente le montant de l'Excédent Brut d'Exploitation."
            rep3.text = "C) Diminue le montant du résultat financier."
            rep4.text = "D) Diminue le montant du résultat d'exploitation."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 41:
            question.value = f"{counter} ) {questions['q41']}"
            rep1.text = "A) La rubrique 13."
            rep2.text = "B) La rubrique 14."
            rep3.text = "C) La rubrique 71."
            rep4.text = "D) La rubrique 75."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()
        
                #================

        elif counter == 42:
            question.value = f"{counter} ) {questions['q42']}"
            rep1.text = "A) La production stockée augmente."
            rep2.text = "B) Les autres charges externes diminuent."
            rep3.text = "C) Les charges de personnel diminuent."
            rep4.text = "D) La marge brute sur vente en l'état augmente."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 43:
            question.value = f"{counter} ) {questions['q43']}"
            rep1.text = "A) C'est un régime juridique propre aux personnes physiques ou morales exerçant une activité libérale réglementée."
            rep2.text = "B) C'est un régime juridique réservé aux agents de l'Etat, aux collectivités locales et aux personnes morales de droit public."
            rep3.text = "C) C'est un ensemble de règles de droit réglementant les relations entre employeurs et employés."
            rep4.text = "D) Les trois réponses précédentes sont fausses."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 44:
            question.value = f"{counter} ) {questions['q44']}"
            rep1.text = "A) Construction."
            rep2.text = "B) Frais de constitution."
            rep3.text = "C) Titres de participation."
            rep4.text = "D) Immobilisations en recherche et développement."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 45:
            question.value = f"{counter} ) {questions['q45']}"
            rep1.text = "A) Une diminution des charges non courantes."
            rep2.text = "B) Une augmentation du résultat d'exploitation."
            rep3.text = "C) Une diminution de la valeur ajoutée (VA)."
            rep4.text = "D) Une augmentation de l'excédent brut d'exploitation (EBE)."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 46:
            question.value = f"{counter} ) {questions['q46']}"
            rep1.text = "A) La vente de marchandises à crédit impacte le résultat de l'entreprise."
            rep2.text = "B) L'augmentation du capital emprunté impacte le résultat de l'entreprise."
            rep3.text = "C) Les charges financières bancaires influencent le résultat de l'entreprise."
            rep4.text = "D) La TVA récupérable impacte le résultat de l'entreprise."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()

        elif counter == 47:
            question.value = f"{counter} ) {questions['q47']}"
            rep1.text = "A) A une clé de répartition choisie arbitrairement."
            rep2.text = "B) Au rapport entre les coûts indirects du centre divisés par le nombre d'unités d'œuvre."
            rep3.text = "C) Au coût de revient de la main-d'œuvre."
            rep4.text = "D) Au taux de consommation d'une activité dans l'élaboration du produit."
            btn_visible()
            rep1.on_click = rep_fausse
            rep2.on_click = rep_fausse
            rep3.on_click = rep_fausse
            rep4.on_click = rep_fausse
            correction.value = ""
            quizpage.update()


        #================

        else:
            qst_container.content=Text("Fin de Test",size=25,text_align=TextAlign.CENTER)
            #correction.value="fin de test"
            question.visible=False
            next_btn.visible=False
            btn_non_visible()
            quizpage.update()
        
    
    question=Text("cliquer sur start pour commencer !!",size=20)
    rep1=ElevatedButton("",width=390,bgcolor=colors.BLUE,visible=False,color=colors.WHITE)
    rep2=ElevatedButton("",width=390,bgcolor=colors.BLUE,visible=False,color=colors.WHITE)
    rep3=ElevatedButton("",width=390,bgcolor=colors.BLUE,visible=False,color=colors.WHITE)
    rep4=ElevatedButton("",width=390,bgcolor=colors.BLUE,visible=False,color=colors.WHITE)
    correction=Text("",size=18) 
    next_btn=ElevatedButton("Start",on_click=next_question,width=390)
    
    qst_container=Container(content=question,bgcolor=colors.AMBER,height=200,padding=10,width=400)
    choix_container=Container(
        content=Column(
            controls=[rep1,rep2,rep3,rep4]
         ),height=225,bgcolor=colors.WHITE,padding=10
    )
    reponse_container=Container(
        correction,
        alignment=alignment.center,
        border_radius=5
    )
    
    quizpage.add(
                menubar,
                qst_container,
                choix_container,
                reponse_container,
                next_btn
    )
    quizpage.update()

app(target=main,view=WEB_BROWSER)
