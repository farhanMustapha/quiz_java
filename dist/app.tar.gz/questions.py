questions={ 
        "q1":"Quelle est la signification du mot 'comptabilité' ?",
        "q2":"vente de m/ses,quel compte a debiter ?",
        "q3":"alimentation de caisse,quel compte debiter ?",
        "q4":"retarait de la banque quel compte a crediter ?",
        "q5":"le bilan est un etat de synthese ?",
        "q6":"Qu'est-ce que l'actif de bilan ?",
        "q7":"Qu'est-ce que le passif de bilan ?",
        "q8":"En quoi consiste un écart de conversion actif ?",
        "q9":"En quoi consiste la CAF ?",
        "q10":"Le compte 3481 est débité du prix de vente lors d'une cession d'immobilisations à crédit, à moins d'un an. Quel compte est crédité selon le type d'immobilisation ?",
        "q11":"un cheque est un ...",
        "q12":"un compte sur carnet est ",
        "q13":"Le taux d'intérêt dans la fonction keynésienne de demande de monnaie :",
        "q14":"La notion de liquidité ",
        "q15":"Les produits alternatifs sont des produits proposés par :",
        "q16":"selon la loi comptable marocaine ,les livres comptables dont la tenue est obligatoire sont :",
        "q17":"Les subventions d’exploitation sont accordées à certaines entreprises pour :",
        "q18":"L’achalandage fait partie intégrante des :",
        "q19":"Pour diminuer son besoin en fonds de roulement (BFR), une entreprise doit :",
        "q20":"Parmi les comptes de régularisation suivants, lesquels sont retracés au passif du bilan ?",
        "q21":"L'Organisation Scientifique du Travail de F.W. Taylor repose sur :",
        "q22":"L’acquisition d’une immobilisation, 50 % par emprunt et 50 % par fonds propres, modifie le montant des éléments suivants :",
        "q23":"Dans quel(s) cas les comptes d’immobilisations amortissables doivent être soldés :",
        "q24":" Quelles sont les opérations qui contribuent à l’augmentation du Fonds de Roulement ?",
        "q25":"En comptabilité, un report à nouveau débiteur signifie que :",
        "q26":"Choisir la ou les bonne(s) affirmation(s) :",
        "q27":"Si l'EBE d'une entreprise s'est amélioré d'une année à l'autre malgré une baisse de VA, cela signifie que :",
        "q28":"Les avances versées sur commande d'une immobilisation corporelle sont comptabilisées dans un compte appartenant à :",
        "q29":"La révocation d'un gérant d'une SARL doit être décidée :",
        "q30":" Le BFR généré par le cycle d'exploitation comprend :",
        "q31":"L'enregistrement comptable d'une facture non parvenue obéit au principe de :",
        
        "q32": "L'inventaire extra-comptable consiste à :",
        "q33": "Quels sont les apports autorisés dans une société anonyme ?",
        "q34": "Un stock final de marchandises inférieur au stock initial signifie :",
        "q35": "Un fonds de roulement positif traduit :",
        "q36": "En comptabilité générale :",
        
        "q37": "Le modèle organisationnel de Max Weber repose sur le ou les principe(s) suivants :",
        "q38": "La valeur ajoutée mesure :",
        "q39": "L'enregistrement comptable des annuités de remboursement de prêts se fait :",
        "q40": "Dans le tableau de formation des résultats, le retraitement de la redevance de crédit-bail :",
        "q41": "La subvention d'équilibre est classée dans :",

        "q42": "L'excédent brut d'exploitation (EBE) augmente lorsque :",
        "q43": "Qu'est-ce que le régime de l'auto-entrepreneur ?",
        "q44": "Indiquez les immobilisations non amortissables :",
        "q45": "Une entreprise industrielle envisage d'externaliser le gardiennage de ses locaux pour un montant de 60 000 DH mensuel, ce qui entraînera le départ de 20 salariés de l'entreprise dont les charges mensuelles de personnel sont de 100 000 DH. Une telle décision aura pour conséquence :",
        "q46": "Choisir la ou les bonne(s) affirmation(s) :",
        "q47": "Dans la méthode des coûts complets, l'unité d'œuvre correspond :"
}





